p_cliNotsite = p_cliNotsite_notfdr;

mmse_p = [p_cliNotsite{1}(1,:);p_cliNotsite{2}(1,:);p_cliNotsite{3}(1,:)]'
mmse_r = [r_cliNotsite{1}(1,:);r_cliNotsite{2}(1,:);r_cliNotsite{3}(1,:)]'
mmse_r_th= mmse_r
mmse_r_th(mmse_p>0.05)=0

mmse_p_log = -log10(mmse_p)

